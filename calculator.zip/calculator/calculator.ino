#include <Keypad.h>
#include <LiquidCrystal.h>

const int rs = 13, en = 12, d4 = 11, d5 = 10, d6 = 9, d7 = 8;
LiquidCrystal lcd(rs, en, d4, d5, d6, d7);

const byte ROWS = 4;
const byte COLS = 4;

char hexakeys[ROWS][COLS] = {
  {'7', '8', '9', '/'},
  {'4', '5', '6', 'X'},
  {'1', '2', '3', '-'},
  {'C', '0', '=', '+'}
};

byte rowPins[ROWS] = {3, 2, A4, A5};
byte colsPins[COLS] = {7, 6, 5, 4};

Keypad customKeypad = Keypad(makeKeymap(hexakeys), rowPins, colsPins, ROWS, COLS);

String input = "";
int firstNum = 0;
int secondNum = 0;
char operation = '\0';
bool isSecond = false;

void setup() {
  Serial.begin(9600);
  lcd.begin(16, 2);
  lcd.setCursor(0, 0);
  lcd.print("Calculator...");
  delay(100);
  lcd.clear();
}

void loop() {
  char key = customKeypad.getKey();

  if (key) {
    Serial.println(key);

    if (key >= '0' && key <= '9') {
      input += key;
      lcd.print(key);
    } else if (key == '+' || key == '-' || key == 'X' || key == '/') {
      firstNum = input.toInt();
      input = "";
      operation = key;
      isSecond = true;
      lcd.print(key);
    } else if (key == '=') {
      if (isSecond) {
        secondNum = input.toInt();
        int result = 0;
        bool valid = true;

        switch (operation) {
          case '+': result = firstNum + secondNum; break;
          case '-': result = firstNum - secondNum; break;
          case 'X': result = firstNum * secondNum; break;
          case '/':
            if (secondNum != 0) {
              result = firstNum / secondNum;
            } else {
              lcd.clear();
              lcd.print("Error: Divide by 0");
              valid = false;
            }
            break;
        }

        if (valid) {
          lcd.clear();
          lcd.print("Answer: ");
          lcd.print(result);
        }

        input = "";
        isSecond = false;
        operation = '\0';
      }
    } else if (key == 'C') {
      input = "";
      firstNum = 0;
      secondNum = 0;
      operation = '\0';
      isSecond = false;
      lcd.clear();
    }
  }
}