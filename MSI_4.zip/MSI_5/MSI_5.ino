#include <LiquidCrystal.h>

LiquidCrystal lcd(12,11,5,4,3,2);


void setup() {
  // put your setup code here, to run once:
  lcd.begin(16,2);
  Serial.begin(9600);
  lcd.print("Ready...");
}

void loop() {
  // put your main code here, to run repeatedly:
  if (Serial.available()){
    char c = Serial.read();
    lcd.clear();
    lcd.print("Recieved: ");
    lcd.setCursor(0,1);
    lcd.print(c);

    Serial.println("You sent: ");
    Serial.println(c);
  }
}
