#include <LiquidCrystal.h>

const int rs =12, en =11, d4 = 5, d5 = 4, d6 = 3, d7 = 2;
LiquidCrystal lcd(rs, en, d4, d5, d6, d7);

int SensorPin = A0;
int SensorValue = 0;
float voltage = 0;
float temperature = 0;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  lcd.begin(16, 2);
  lcd.print("LM35 Temp: ");
}

void loop() {
  // put your main code here, to run repeatedly:
  SensorValue = analogRead(SensorPin);

  voltage = SensorValue * (5.0 / 1023.0);

  temperature = voltage * 100;

  Serial.print("ADC Value: ");
  Serial.print(SensorValue);
  Serial.print("   |   Voltage: ");
  Serial.print(voltage);
  Serial.print(" V  |  Temp: ");
  Serial.print(temperature);
  Serial.print(" °C");

  // Print to LCD
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Temp: ");
  lcd.print(temperature);
  lcd.print(" °C");

  lcd.setCursor(0, 1);
  lcd.print("ADC: ");
  lcd.print(SensorValue);

  delay(500);
}
