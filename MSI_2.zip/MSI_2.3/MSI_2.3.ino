// Four-Way Traffic Light Control

int N_R = 2, N_Y = 3, N_G = 4;
int S_R = 5, S_Y = 6, S_G = 7;
int E_R = 8, E_Y = 9, E_G = 10;
int W_R = 11, W_Y = 12, W_G = 13;

void setup() {
  // Set all as output
  int pins[] = {N_R, N_Y, N_G, S_R, S_Y, S_G, E_R, E_Y, E_G, W_R, W_Y, W_G};
  for (int i = 0; i < 12; i++) {
    pinMode(pins[i], OUTPUT);
  }
}

void loop() {
  // Phase 1: North-South Green, East-West Red
  digitalWrite(N_G, HIGH);
  digitalWrite(S_G, HIGH);
  digitalWrite(N_R, LOW);
  digitalWrite(S_R, LOW);
  digitalWrite(E_R, HIGH);
  digitalWrite(W_R, HIGH);
  delay(5000);

  // Phase 2: North-South Yellow
  digitalWrite(N_G, LOW);
  digitalWrite(S_G, LOW);
  digitalWrite(N_Y, HIGH);
  digitalWrite(S_Y, HIGH);
  delay(2000);
  digitalWrite(N_Y, LOW);
  digitalWrite(S_Y, LOW);

  // Phase 3: East-West Green, North-South Red
  digitalWrite(N_R, HIGH);
  digitalWrite(S_R, HIGH);
  digitalWrite(E_R, LOW);
  digitalWrite(W_R, LOW);
  digitalWrite(E_G, HIGH);
  digitalWrite(W_G, HIGH);
  delay(5000);

  // Phase 4: East-West Yellow
  digitalWrite(E_G, LOW);
  digitalWrite(W_G, LOW);
  digitalWrite(E_Y, HIGH);
  digitalWrite(W_Y, HIGH);
  delay(2000);
  digitalWrite(E_Y, LOW);
  digitalWrite(W_Y, LOW);
}
