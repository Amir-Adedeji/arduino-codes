#include <LiquidCrystal.h>

LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

void setup() {
  // put your setup code here, to run once:
  // Setup the lcd's number of colums and rows
  lcd.begin(16, 1); 
}

void loop() {
  // put your main code here, to run repeatedly:
  // Set cursor to line 1
  lcd.setCursor(0,1);

// Print message
  lcd.print("Foxtroit Group");
  delay(1000);  

  lcd.clear();
  lcd.print("21/30GR041-46");
  delay(1000);

  lcd.clear();
  lcd.print("Thank you!");
  delay(1000);
}
